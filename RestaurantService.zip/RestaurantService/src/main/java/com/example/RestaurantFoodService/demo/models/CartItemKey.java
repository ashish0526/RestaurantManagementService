package com.example.RestaurantFoodService.demo.models;

import java.io.Serializable;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartItemKey implements Serializable {

    private Cart cart;
    private MenuItem product;

    public CartItemKey(Cart cart, MenuItem product) {
        this.cart = cart;
        this.product = product;
    }

    public CartItemKey() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartItemKey that = (CartItemKey) o;
        return Objects.equals(cart, that.cart) && Objects.equals(product, that.product);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cart, product);
    }
}

