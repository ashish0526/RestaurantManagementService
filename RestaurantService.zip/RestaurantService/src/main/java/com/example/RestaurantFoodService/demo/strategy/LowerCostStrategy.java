package com.example.RestaurantFoodService.demo.strategy;

import com.example.RestaurantFoodService.demo.models.Order;
import com.example.RestaurantFoodService.demo.models.OrderItem;
import com.example.RestaurantFoodService.demo.models.Restaurant;
import org.springframework.boot.autoconfigure.web.WebProperties;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class LowerCostStrategy implements RestaurantStrategy {

    @Override
    public boolean selectRestaurants(Order order, Map<String, List<Restaurant>> itemRestaurants) {
        for (OrderItem entry : order.getItems()) { // Assuming order has a method getItems()
            String itemName = entry.getProduct().getProductName();
            int quantity = entry.getQuantity();

            List<Restaurant> restaurants = itemRestaurants.get(itemName);
            if (restaurants == null || restaurants.isEmpty()) {
                return false; // No restaurants available for this item
            }

            restaurants.sort(Comparator.comparingDouble(r -> r.getMenu().get(itemName).getPrice()));

            boolean fulfilled = false;
            for (Restaurant restaurant : restaurants) {
                if (restaurant.getCapacity() - restaurant.getCurrentLoad() >= quantity) {
                    restaurant.setCurrentLoad(restaurant.getCurrentLoad() + quantity);
                    order.setRestaurantId(restaurant.getRestaurantId()); // Assuming setRestaurantId is correct
                    fulfilled = true;
                    break;
                }
            }

            if (!fulfilled) {
                return false; // Could not fulfill this item from any restaurant
            }
        }
        return true;
    }

}
