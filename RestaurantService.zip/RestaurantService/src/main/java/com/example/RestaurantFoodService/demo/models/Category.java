package com.example.RestaurantFoodService.demo.models;


import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class Category extends BaseEntity {

    private Long categoryId;
    private String categoryName;
    private String imgUrl;
    private List<MenuItem> products = new ArrayList<>();

    public Category() {
    }

    public Category(Long categoryId) {
        this.categoryId = categoryId;
    }

    public void addProduct(MenuItem product) {
        this.products.add(product);
        product.setCategory(this);
    }

    public void removeProduct(MenuItem product) {
        this.products.remove(product);
        product.setCategory(null);
    }
}
