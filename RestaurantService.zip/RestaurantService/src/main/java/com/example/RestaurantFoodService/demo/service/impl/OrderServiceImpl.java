package com.example.RestaurantFoodService.demo.service.impl;

import com.example.RestaurantFoodService.demo.dto.AddressDTO;
import com.example.RestaurantFoodService.demo.dto.OrderDTO;
import com.example.RestaurantFoodService.demo.dto.PaymentDTO;
import com.example.RestaurantFoodService.demo.dto.PriceDTO;
import com.example.RestaurantFoodService.demo.models.*;
import com.example.RestaurantFoodService.demo.models.MenuItem;
import com.example.RestaurantFoodService.demo.repository.OrderRepository;
import com.example.RestaurantFoodService.demo.service.AuthenticationFacade;
import com.example.RestaurantFoodService.demo.service.OrderService;
import com.example.RestaurantFoodService.demo.service.UserService;
import org.aspectj.weaver.ast.Or;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.logging.Logger;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {


    private final OrderRepository orderRepository;
    private final AuthenticationFacade authenticationFacade;
    private final UserService userService;

    public OrderServiceImpl(OrderRepository orderRepository, AuthenticationFacade authenticationFacade, UserService userService) {
        this.orderRepository = orderRepository;
        this.authenticationFacade = authenticationFacade;
        this.userService = userService;
    }

    private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(OrderServiceImpl.class);

    @Override
    public List<OrderDTO> getOrders(int page, int size) {
        Page<Order> orders = this.orderRepository.getOrderByUserUsername(this.authenticationFacade.getUsername(),
                PageRequest.of(page, size, Sort.by("updated").descending()));
        return orders.stream().map(order -> new OrderDTO(order.getOrderId(), null, new PriceDTO(order.getTotalPrice()), new PriceDTO(0),
                new PriceDTO(order.getTax()), order.getCreated(), order.getOrderStatus(), null, null)).toList();
    }

    @Override
    public OrderDTO getOrder(UUID orderId) {
        Order order = orderRepository.getOrderByOrderIdAndUserUsername(orderId, authenticationFacade.getUsername()).orElse(null);
        if (order == null) {
            return null; // Handle order not found
        }

        // Logic for constructing OrderDTO (same as in your original code)
        // ...
        return new OrderDTO(order.getOrderId());
    }

    @Override
    public OrderDTO getOrder(UUID orderId, String emailId) {
        Optional<Order> orderOptional = orderRepository.getOrderByOrderIdAndBillingAddressEmailId(orderId, emailId);
        if (orderOptional.isEmpty()) {
            LOGGER.info(String.format("No order for orderId %s and email %s", orderId, emailId));
            return null;
        }
        Order order = orderOptional.get();
        return new OrderDTO(order.getOrderId(), null, new PriceDTO(order.getTotalPrice()),
                new PriceDTO(0), new PriceDTO(order.getTax()), order.getCreated(), order.getOrderStatus(), null, null);
    }

    @Override
    public OrderDTO addOrder(ShoppingCart shoppingCart, AddressDTO addressDTO, PaymentDTO paymentDTO) {
        Order order = new Order();
        order.setOrderId(UUID.randomUUID());
        order.setOrderStatus(OrderStatus.RECEIVED);

        if (authenticationFacade.isLoggedIn()) {
            userService.findByUsername(authenticationFacade.getUsername()).ifPresent(order::setUser);
        }

        order.setTax(shoppingCart.getTax());
        order.setTotalPrice(shoppingCart.getPrice());
        shoppingCart.getCartItems().forEach(cartItem -> {
            OrderItem orderItem = new OrderItem();
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(cartItem.getPrice().getPrice());
            MenuItem product = new MenuItem();
            product.setProductId(cartItem.getProduct().getProductId());
            orderItem.setProduct(product);
            orderItem.setOrder(order);
            order.getItems().add(orderItem);
        });

        order.setBillingAddress(new Address(addressDTO.getId()));
        order.setPaymentMethod(new PaymentMethod(paymentDTO.getId()));

        Order persistedOrder = orderRepository.save(order);
        return new OrderDTO(persistedOrder.getOrderId());
    }
}
