package com.example.RestaurantFoodService.demo.repository;

import com.example.RestaurantFoodService.demo.models.MenuItem;
import com.example.RestaurantFoodService.demo.models.Restaurant;

import java.util.ArrayList;
import java.util.List;

public interface RestaurantRepository {

    Restaurant save(Restaurant restaurant);

    Restaurant findById(Long id);

    ArrayList<Restaurant> findAllRestaurants();


    void updateMenu(Long id, List<MenuItem> newMenu);

}
