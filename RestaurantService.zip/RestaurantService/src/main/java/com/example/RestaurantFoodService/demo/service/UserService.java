package com.example.RestaurantFoodService.demo.service;

import com.example.RestaurantFoodService.demo.dto.UserDTO;
import com.example.RestaurantFoodService.demo.models.RegistrationForm;
import com.example.RestaurantFoodService.demo.models.User;
import com.example.RestaurantFoodService.demo.models.UserUpdateForm;

import java.util.Optional;

public interface UserService {
    void save(RegistrationForm registrationForm);
    boolean emailExists(String emailId);
    UserDTO me();
    void update(UserUpdateForm userUpdateForm);

    Optional<User> findByUsername(String username);
}
