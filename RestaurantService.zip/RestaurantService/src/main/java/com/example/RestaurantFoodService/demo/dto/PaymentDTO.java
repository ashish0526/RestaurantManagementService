package com.example.RestaurantFoodService.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentDTO {

    private Long id;
    private String creditCard;
    private String cvv;
    private String fullName;
    private int expiryMonth;
    private int expiryYear;
    private boolean myDefault;

    // Getters and Setters (omitted for brevity)

    public PaymentDTO() {
    }

    public PaymentDTO(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return String.format("%s, %s/%s", creditCard, expiryMonth, expiryYear);
    }
}
