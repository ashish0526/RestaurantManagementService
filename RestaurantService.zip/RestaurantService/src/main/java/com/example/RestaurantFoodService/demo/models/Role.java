package com.example.RestaurantFoodService.demo.models;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Role extends BaseEntity {

    private Integer id;
    private UserRole name;
    private List<User> users = new ArrayList<>();

    /*@Override
    public String getAuthority() {
        return this.name.toString();
    }*/
}