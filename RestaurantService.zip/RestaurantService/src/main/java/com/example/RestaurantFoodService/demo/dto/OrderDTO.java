package com.example.RestaurantFoodService.demo.dto;

import com.example.RestaurantFoodService.demo.models.OrderStatus;
import lombok.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.time.LocalDateTime;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderDTO {
    private UUID orderId;
    private List<OrderItemDTO> items;
    private PriceDTO totalPrice;
    private PriceDTO subtotal;
    private PriceDTO tax;
    private Long orderDate;
    private OrderStatus status;
    private AddressDTO billingAddress;
    private PaymentDTO payment;

    public OrderDTO(UUID orderId) {
        this(orderId, null, null, null, null, null, null, null, null);
    }


}
