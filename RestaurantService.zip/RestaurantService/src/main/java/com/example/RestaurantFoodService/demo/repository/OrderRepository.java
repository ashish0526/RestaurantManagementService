package com.example.RestaurantFoodService.demo.repository;

import com.example.RestaurantFoodService.demo.models.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.Optional;
import java.util.UUID;

public interface OrderRepository {

    Order save(Order order);

    Optional<Order> getOrderByOrderIdAndUserUsername(UUID orderId, String username);

    Optional<Order> getOrderByOrderIdAndBillingAddressEmailId(UUID orderId, String emailId);

    Page<Order> getOrderByUserUsername(String username, Pageable pageable);
}
