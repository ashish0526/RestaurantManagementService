package com.example.RestaurantFoodService.demo.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Cart extends BaseEntity {

    private Long cartId;
    private User user;
    private List<CartItem> cartItems = new ArrayList<>();

    public Cart() {
    }

    public Cart(Long cartId, User user) {
        this.cartId = cartId;
        this.user = user;
    }

    public void addCartItem(CartItem cartItem) {
        this.cartItems.add(cartItem);
    }

    public void removeCartItem(CartItem cartItem) {
        this.cartItems.remove(cartItem);
    }
}
