package com.example.RestaurantFoodService.demo.repository;

import com.example.RestaurantFoodService.demo.models.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemoryOrderRepository implements OrderRepository {
    private final Map<UUID, Order> orderDatabase = new ConcurrentHashMap<>();

    @Override
    public Order save(Order order) {
        orderDatabase.put(order.getOrderId(), order);
        return order;
    }

    @Override
    public Optional<Order> getOrderByOrderIdAndUserUsername(UUID orderId, String username) {
        // Add logic to check username
        return Optional.ofNullable(orderDatabase.get(orderId)); // Simplified; implement actual logic as needed
    }

    @Override
    public Optional<Order> getOrderByOrderIdAndBillingAddressEmailId(UUID orderId, String emailId) {
        Order order = orderDatabase.get(orderId);
        if (order != null && order.getBillingAddress().getEmailId().equals(emailId)) {
            return Optional.of(order);
        }
        return Optional.empty();
    }

    @Override
    public Page<Order> getOrderByUserUsername(String username, Pageable pageable) {
        // Implement pagination logic (simplified)
        List<Order> filteredOrders = new ArrayList<>(orderDatabase.values()); // Filter by username if needed
        return new PageImpl<>(filteredOrders, pageable, filteredOrders.size());
    }
}
