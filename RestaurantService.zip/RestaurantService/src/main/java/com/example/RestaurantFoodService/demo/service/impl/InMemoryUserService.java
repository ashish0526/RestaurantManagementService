package com.example.RestaurantFoodService.demo.service.impl;

import com.example.RestaurantFoodService.demo.dto.UserDTO;
import com.example.RestaurantFoodService.demo.models.*;
import com.example.RestaurantFoodService.demo.service.AuthenticationFacade;
import com.example.RestaurantFoodService.demo.service.EmailService;
import com.example.RestaurantFoodService.demo.service.UserService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Transactional
public class InMemoryUserService implements UserService {

    private final Map<String, User> userDatabase = new ConcurrentHashMap<>();
    private final Map<String, Role> roleDatabase = new ConcurrentHashMap<>();
    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    private final EmailService emailService;
    private final AuthenticationFacade authenticationFacade;

    public InMemoryUserService(BCryptPasswordEncoder bCryptPasswordEncoder, EmailService emailService, AuthenticationFacade authenticationFacade) {
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
        this.emailService = emailService;
        this.authenticationFacade = authenticationFacade;

        // Preload roles for the sake of example
        Role userRole = new Role();
        userRole.setId(1);
        userRole.setName(UserRole.USER);
        roleDatabase.put(UserRole.USER.name(), userRole);
    }

    @Override
    public void save(RegistrationForm registrationForm) {
        Role role = roleDatabase.get(UserRole.USER.name());
        User user = new User();
        user.setFirstName(registrationForm.getFirstName());
        user.setLastName(registrationForm.getLastName());
        user.setPassword(bCryptPasswordEncoder.encode(registrationForm.getPassword()));
        user.setEmailId(registrationForm.getEmailId());
        user.setUsername(registrationForm.getEmailId());
        user.setRoles(new HashSet<>(Collections.singletonList(role)));
        userDatabase.put(user.getUsername(), user);
        emailService.sendEmail(EmailType.WELCOME, registrationForm.getEmailId());
    }

    @Override
    public boolean emailExists(String emailId) {
        return userDatabase.containsKey(emailId);
    }

    @Override
    public UserDTO me() {
        String username = authenticationFacade.getUsername();
        User user = userDatabase.get(username);
        if (user == null) {
            return null;
        }
        return new UserDTO(user.getFirstName(), user.getLastName(), user.getEmailId());
    }

    @Override
    public void update(UserUpdateForm userUpdateForm) {
        String username = authenticationFacade.getUsername();
        User user = userDatabase.get(username);
        if (user != null) {
            user.setFirstName(userUpdateForm.firstName());
            user.setLastName(userUpdateForm.lastName());
            userDatabase.put(username, user);
        }
    }

    @Override
    public Optional<User> findByUsername(String username) {
        User user = userDatabase.get(username);
        return Optional.ofNullable(user);
    }
}
