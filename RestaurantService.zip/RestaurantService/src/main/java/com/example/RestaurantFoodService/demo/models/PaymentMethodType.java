package com.example.RestaurantFoodService.demo.models;

public enum PaymentMethodType {
    VISA, MASTERCARD, AMX, DISCOVER
}
