package com.example.RestaurantFoodService.demo.models;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserAddress extends BaseEntity {

    private Long addressId;
    private User user;
    private String emailId;
    private String firstName;
    private String lastName;
    private String streetAddress1;
    private String streetAddress2;
    private String state;
    private String city;
    private String postalCode;
    private String country;
    private boolean myDefault;
    private String phoneNumber;
    private AddressType addressType;
}
