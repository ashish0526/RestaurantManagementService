package com.example.RestaurantFoodService.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AddressDTO {

    private Long id;
    private String firstName;
    private String lastName;
    private String emailId;
    private String street1;
    private String street2;
    private String country;
    private String state;
    private String city;
    private String postalCode;
    private boolean myDefault;
    private String type;
    private String phoneNumber;




    @Override
    public String toString() {
        return String.format("%s %s, %s, %s, %s, %s, %s, %s", firstName, lastName, street1, street2, city, state, postalCode, country);
    }
}