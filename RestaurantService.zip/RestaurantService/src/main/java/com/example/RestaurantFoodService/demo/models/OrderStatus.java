package com.example.RestaurantFoodService.demo.models;


    public enum OrderStatus {
        RECEIVED, BEING_PREPARED, PREPARED, COMPLETE
    }

