package com.example.RestaurantFoodService.demo.models;

public enum AddressType {
 BILLING, SHIPPING
}
