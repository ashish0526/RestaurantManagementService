package com.example.RestaurantFoodService.demo.models;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PaymentMethod {

    private Long paymentMethodId;
    private String creditCardNumber;
    private String cvv;
    private int expiryMonth;
    private int expiryYear;
    private String fullName;
    private PaymentMethodType paymentMethodType;
    private List<Order> orders = new ArrayList<>();

    public PaymentMethod(Long paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }
}
