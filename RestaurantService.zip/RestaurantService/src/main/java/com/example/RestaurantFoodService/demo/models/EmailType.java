package com.example.RestaurantFoodService.demo.models;

public enum EmailType {

    WELCOME, ORDER_CONFIRMATION
}
