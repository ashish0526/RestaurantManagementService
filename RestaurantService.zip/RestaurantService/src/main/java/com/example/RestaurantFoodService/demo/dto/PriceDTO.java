package com.example.RestaurantFoodService.demo.dto;

import com.example.RestaurantFoodService.demo.RestaurantUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.DecimalFormat;


@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class PriceDTO {
    private float price;
    private CurrencyDTO currency;
    private static final DecimalFormat decimalFormat = new DecimalFormat("#.##");

    public PriceDTO(float price) {
        this(Float.parseFloat(decimalFormat.format(price)), RestaurantUtils.getDefaultCurrency());
    }

    @Override
    public String toString() {
        return String.format("%s%s", currency.code(), price);
    }



}
