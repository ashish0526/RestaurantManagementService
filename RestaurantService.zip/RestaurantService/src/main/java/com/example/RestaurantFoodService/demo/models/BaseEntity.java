package com.example.RestaurantFoodService.demo.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class BaseEntity {

    private Long created;
    private Long updated;

    public BaseEntity() {
        long currentTime = System.currentTimeMillis();
        this.created = currentTime;
        this.updated = currentTime;
    }

    public void updateTimestamp() {
        this.updated = System.currentTimeMillis();
    }
}
