package com.example.RestaurantFoodService.demo.models;


import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Restaurant extends BaseEntity {

    private Long restaurantId;
    private String name;
    private String address;
    private String phone;
    private String emailId;
    private int capacity;
    private double rating;
    private Map<String, MenuItem> menu;
    private List<Order> orders = new ArrayList<>();
    private boolean enabled;
    private int currentLoad;

    // Constructor to initialize mandatory fields
    public Restaurant(Long restaurantId, String name, String address, String phone, String emailId,
                      int capacity, double rating, Map<String, MenuItem> menu) {
        this.restaurantId = restaurantId;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.emailId = emailId;
        this.capacity = capacity;
        this.rating = rating;
        this.menu = menu;
        this.enabled = true;
        this.currentLoad = 0;
    }

    // Method to add an order
    public void addOrder(Order order) {
        this.orders.add(order);
    }

    // Method to remove an order
    public void removeOrder(Order order) {
        this.orders.remove(order);
    }
}
