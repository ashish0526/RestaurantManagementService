package com.example.RestaurantFoodService.demo;

import com.example.RestaurantFoodService.demo.service.OrderService;
import com.example.RestaurantFoodService.demo.service.RestaurantService;
import com.example.RestaurantFoodService.demo.strategy.LowerCostStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// Config.java
/*
@Configuration
public class Config {
    @Bean
    public RestaurantService restaurantService() {
        return new RestaurantService();
    }

    @Bean
    public OrderService orderService(RestaurantService restaurantService) {
        return new OrderService(restaurantService, new LowerCostStrategy());
    }
}
*/
