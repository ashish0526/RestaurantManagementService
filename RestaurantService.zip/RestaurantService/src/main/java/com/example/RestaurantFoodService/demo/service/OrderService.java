package com.example.RestaurantFoodService.demo.service;

import com.example.RestaurantFoodService.demo.dto.AddressDTO;
import com.example.RestaurantFoodService.demo.dto.OrderDTO;
import com.example.RestaurantFoodService.demo.dto.PaymentDTO;
import com.example.RestaurantFoodService.demo.models.Cart;
import com.example.RestaurantFoodService.demo.models.ShoppingCart;

import java.util.List;
import java.util.UUID;

public interface OrderService {

    List<OrderDTO> getOrders(int page, int size);

    OrderDTO getOrder(UUID orderId);

    OrderDTO getOrder(UUID orderId, String emailId);

    OrderDTO addOrder(ShoppingCart orderCart, AddressDTO addressDTO, PaymentDTO paymentDTO);

}
