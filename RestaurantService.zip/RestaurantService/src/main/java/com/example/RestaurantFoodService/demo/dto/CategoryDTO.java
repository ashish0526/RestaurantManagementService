package com.example.RestaurantFoodService.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CategoryDTO {
    private long id;
    private String name;
    private List<ProductDTO> products;

    public CategoryDTO(long id, String name) {
        this(id, name, null);
    }


}