package com.example.RestaurantFoodService.demo.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Order extends BaseEntity {

    private UUID orderId;
    private User user;
    private float tax;
    private float totalPrice;
    private OrderStatus orderStatus;
    private Address billingAddress;
    private PaymentMethod paymentMethod;
    private List<OrderItem> items = new ArrayList<>();
    private Long restaurantId;

    public Order(UUID orderId, User user, float tax, float totalPrice, OrderStatus orderStatus, Address billingAddress, PaymentMethod paymentMethod, Long restaurantId) {
        this.orderId = orderId;
        this.user = user;
        this.tax = tax;
        this.totalPrice = totalPrice;
        this.orderStatus = orderStatus;
        this.billingAddress = billingAddress;
        this.paymentMethod = paymentMethod;
        this.restaurantId = restaurantId;
    }

    public void addItem(OrderItem item) {
        this.items.add(item);
        item.setOrder(this);
    }

    public void removeItem(OrderItem item) {
        this.items.remove(item);
        item.setOrder(null);
    }
}
