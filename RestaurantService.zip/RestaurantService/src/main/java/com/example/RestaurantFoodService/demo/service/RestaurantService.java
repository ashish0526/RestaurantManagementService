package com.example.RestaurantFoodService.demo.service;

import com.example.RestaurantFoodService.demo.models.MenuItem;
import com.example.RestaurantFoodService.demo.models.Restaurant;
import com.example.RestaurantFoodService.demo.repository.RestaurantRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RestaurantService {

    private final RestaurantRepository restaurantRepository;

    public RestaurantService(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }

    public Restaurant registerRestaurant(Restaurant restaurant) {
        return restaurantRepository.save(restaurant);
    }

    public void updateMenu(Long restaurantId, List<MenuItem> newMenuItems) {
        if (restaurantRepository.findById(restaurantId) == null) {
            throw new IllegalArgumentException("Restaurant not found");
        }
        restaurantRepository.updateMenu(restaurantId, newMenuItems);
    }
}