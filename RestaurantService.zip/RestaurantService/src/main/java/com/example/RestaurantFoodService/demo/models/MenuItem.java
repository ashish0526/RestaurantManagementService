package com.example.RestaurantFoodService.demo.models;

import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MenuItem extends BaseEntity {

    private UUID productId;
    private String productName;
    private float price;
    private String description;
    private String imgUrl;
    private boolean favorite;
    private Category category;
    private List<CartItem> cartItems = new ArrayList<>();

}