package com.example.RestaurantFoodService.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrderItemDTO {
    private long orderItemId;
    private ProductDTO product;
    private PriceDTO price;
    private int quantity;
    private PriceDTO subtotal;


}
