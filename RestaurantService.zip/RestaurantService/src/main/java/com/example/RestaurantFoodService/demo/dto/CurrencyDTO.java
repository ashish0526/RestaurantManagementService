package com.example.RestaurantFoodService.demo.dto;

import lombok.*;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyDTO {
    private String currency;
    private String code;

    public String code() {
      return code;
    }
}
