package com.example.RestaurantFoodService.demo.dto;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductDTO {
    private UUID productId;
    private String name;
    private String imgUrl;
    private String description;
    private PriceDTO price;
    private CategoryDTO category;



}