package com.example.RestaurantFoodService.demo.repository;

import com.example.RestaurantFoodService.demo.models.MenuItem;
import com.example.RestaurantFoodService.demo.models.Restaurant;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class InMemoryRestaurantRepository implements RestaurantRepository {
    private final Map<Long, Restaurant> restaurantDatabase;
    private  Long nextId ;

    public InMemoryRestaurantRepository() {
        this.restaurantDatabase = new HashMap<>();
        this.nextId = 1L;
    }

    @Override
    public Restaurant save(Restaurant restaurant) {
        restaurant.setRestaurantId(nextId++);
        restaurantDatabase.put(restaurant.getRestaurantId(), restaurant);
        return restaurant;
    }

    @Override
    public Restaurant findById(Long id) {
        return restaurantDatabase.get(id);
    }

    @Override
    public ArrayList<Restaurant> findAllRestaurants() {
        return new ArrayList<>(restaurantDatabase.values());
    }

    @Override
    public void updateMenu(Long id, List<MenuItem> newMenuItems) {
        Restaurant restaurant = restaurantDatabase.get(id);
        if (restaurant != null) {
            // Clear the existing menu
            restaurant.getMenu().clear();
            // Populate the new menu
            for (MenuItem item : newMenuItems) {
                restaurant.getMenu().put(item.getProductName(), item); // Assuming MenuItem has a method getProductName()
            }
        }
    }

}
