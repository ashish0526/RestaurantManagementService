package com.example.RestaurantFoodService.demo.models;

public enum UserAuthProvider {

    GOOGLE, FACEBOOK
}
