package com.example.RestaurantFoodService.demo.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderItem extends BaseEntity {

    private Long orderItemId;
    private int quantity;
    private float price;
    private MenuItem product;
    private Order order;


}
