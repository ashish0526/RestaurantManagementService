package com.example.RestaurantFoodService.demo.models;

public enum UserRole {

    USER, ADMIN
}
