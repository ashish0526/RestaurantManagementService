package com.example.RestaurantFoodService.demo.strategy;

import com.example.RestaurantFoodService.demo.models.Order;
import com.example.RestaurantFoodService.demo.models.Restaurant;

import java.util.List;
import java.util.Map;

public interface RestaurantStrategy {

    boolean selectRestaurants(Order order, Map<String, List<Restaurant>> itemRestaurants);
}
