package com.example.RestaurantFoodService.demo.models;

import java.util.ArrayList;
import java.util.List;

import com.example.RestaurantFoodService.demo.models.AddressType;
import com.example.RestaurantFoodService.demo.models.Order;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class Address extends BaseEntity {

    private Long addressId;
    private String emailId;
    private String firstName;
    private String lastName;
    private String streetAddress1;
    private String streetAddress2;
    private String state;
    private String city;
    private String postalCode;
    private String country;
    private String phoneNumber;
    private AddressType addressType;
    private List<Order> orders;

    public Address(Long id) {
        addressId = id;
    }


}
