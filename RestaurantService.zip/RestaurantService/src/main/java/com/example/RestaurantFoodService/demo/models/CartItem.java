package com.example.RestaurantFoodService.demo.models;

import com.example.RestaurantFoodService.demo.dto.PriceDTO;
import com.example.RestaurantFoodService.demo.dto.ProductDTO;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartItem {
    private ProductDTO product;
    private PriceDTO price;
    private int quantity;
}
