package com.example.RestaurantFoodService.demo.models;

import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;



import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
public class User  {

    private Long userId;
    private String firstName;
    private String lastName;
    private String emailId;
    private String username;
    private String phone;
    private String password;
    private boolean enabled;
    private boolean locked;
    private boolean nonExpired;
    private Set<Role> roles = new HashSet<>();


   /*
    If there was UserRegistratio then we extend UserDetails..
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.roles;
    }

    @Override
    public boolean isAccountNonExpired() {
        return this.nonExpired;
    }

    @Override
    public boolean isAccountNonLocked() {
        return !this.locked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Adjust based on your requirements
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }*/
}
